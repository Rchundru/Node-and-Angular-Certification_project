export class Product {
    name: string = "";
    department: string ="";
    price: number = 0;
    discountPrice: number = 0;
    image: string ="";
    description: string ="";
}