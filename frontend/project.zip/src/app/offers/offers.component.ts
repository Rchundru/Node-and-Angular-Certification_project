import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {

  productList: any = [];
  isAdmin: Boolean;

  constructor(private _httpClient: HttpClient) {
    this.isAdmin = localStorage.getItem('userAccess') == 'admin' ? true : false;
  }

  ngOnInit(): void {

      this._httpClient.get<any>('http://localhost:8080/products')
      .subscribe(result => {
        for (let res of result["productList"]) {
          if (res.discountPrice != res.price) {
            this.productList.push(res);
          }
        }
      }, error => {
        console.log((error)); 
      })
  }

  addtocart(id: any) {
    localStorage.setItem('cart', id);
  }

}
